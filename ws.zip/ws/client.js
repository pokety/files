import { WebSocket } from "ws";

const ws=new WebSocket("ws://localhost:8282")


ws.onmessage=(ev)=>{
    console.log(ev.data)
}