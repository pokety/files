import {WebSocketServer}from "ws"
import inquirer from "inquirer"
import fs from "fs-extra"
import express from "express"
import {fileURLToPath } from 'url';
import path,{ dirname } from 'path';

var uri=''
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app=express()

app.use('/static', express.static('public'))

app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname + '/client.html'))
    uri=`/static/ext/`
})


const wss= new WebSocketServer({port:8282})
wss.setMaxListeners(0)
var sockets=new Map()
wss.on("connection",(socket)=>{
    socket.onmessage=(dat)=>{
        socket.id=dat.data
        sockets.set(dat.data,socket)
        menu()
    }
    socket.close=()=>{
        sockets.delete(socket.id)
        console.log(sockets)
    }
})


const question=inquirer.createPromptModule()


async function menu(){
    process.stdout.write('\x1Bc')
    const client=await question({
        name:"cliente",
        type:"text",
    })
    let videos=await fs.readdirSync("./public/ext")
    const selected=await question({
        name:"select",
        type:"list",
        choices:videos
    })

    if(sockets.get(client.cliente)){
        sockets.get(client.cliente).send(uri + selected.select)
        menu()
    }else{
        console.log("nao")
        menu()
    }
}


app.listen(3000)